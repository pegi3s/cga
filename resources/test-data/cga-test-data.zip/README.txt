|---------------------------------------------------------------------
|
|   1. Running the full pipeline
|
|---------------------------------------------------------------------

- Edit the "cga.params" file to set the "host_working_dir" path.

- Then run:

    ./run.sh /path/to/project-directory "-n 1"
    
Where "-n 1" indicates that 1 is the maximum number of parallel tasks that can be executed.

The "run.sh" script executes the neccessary "docker run" command to run the Compi-Docker image.
